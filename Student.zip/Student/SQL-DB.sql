create table Student(
Id int primary key identity(1,1),
Ism varchar(50),
Familiya varchar(50),
Yosh int,
payment bit,
Fan varchar(30)
)

INSERT INTO Student (Ism, Familiya, Yosh, payment, Fan)
    VALUES ('Ali', 'Aliyev', 13, 1, 'Ingliz tili');

SELECT * FROM Student;
GO

CREATE PROCEDURE sp_AddStudent
    @Ism NVARCHAR(50),
    @Familiya NVARCHAR(50),
    @Yosh INT,
    @payment BIT,
    @Fan VARCHAR(30)
AS
BEGIN
    INSERT INTO Student (Ism, Familiya, Yosh, payment, Fan)
    VALUES (@Ism, @Familiya, @Yosh, @payment, @Fan);
END
GO

CREATE PROCEDURE sp_GetAllStudents
AS
BEGIN
    SELECT * FROM Student
END
GO

CREATE PROCEDURE sp_GetStudentById
    @Id INT
AS
BEGIN
    SELECT * FROM Student WHERE Id = @Id
END
GO

CREATE PROCEDURE sp_UpdateStudent
    @Id INT,
    @Ism NVARCHAR(50),
    @Familiya NVARCHAR(50),
    @Yosh INT,
    @payment BIT,
    @Fan VARCHAR(20)
AS
BEGIN
    UPDATE Student
    SET Ism = @Ism, Familiya = @Familiya, Yosh = @Yosh, payment = @payment, Fan = @Fan
    WHERE Id = @Id
END
GO

CREATE PROCEDURE sp_DeleteStudent
    @Id INT
AS
BEGIN
    DELETE FROM Student WHERE Id = @Id
END
GO



DROP PROCEDURE sp_GetStudentsByFan;
GO

CREATE PROCEDURE sp_GetStudentsByFan
    @Fan VARCHAR(20)
AS
BEGIN
    SELECT Id, Ism, Familiya, Yosh, Fan, payment
    FROM Student
    WHERE Fan = @Fan
END
GO

--Tekshirish 
USE Lesson;
SELECT * FROM sys.tables;
-----------------

--Qo'shish
EXEC sp_AddStudent 
    @Ism = 'Ali', 
    @Familiya = 'Valiyev', 
    @Yosh = 20, 
    @payment = 1, 
    @Fan = 'Matematika';
